# -*- coding: utf-8 -*-
import sys
default_encoding = 'utf-8'
if sys.getdefaultencoding() != default_encoding:
      reload(sys)
      sys.setdefaultencoding(default_encoding)
import matplotlib.pyplot as plt
plt.rcdefaults()
fig, ax = plt.subplots()
from pylab import *
mpl.rcParams['font.sans-serif'] = ['SimHei']
for i in range(1, len(sys.argv)):
     url = sys.argv[1]
     excalurl=sys.argv[2]
   
import matplotlib.pyplot as plt
# ����xlrdģ��
import xlrd
# �����ļ�����·��
fname =excalurl
# ���ļ�
filename = xlrd.open_workbook(fname)
sheets = filename.nsheets
# �õ�����һ���б�����[u'etsy_sheet']
sheet_list = filename.sheet_names()
sheet = filename.sheets()[0]  # ͨ��sheet�������sheet����
print sheet
# ��ȡ����
nrows = sheet.nrows
print nrows
# ��ȡ����
ncols = sheet.ncols
# Example data
# The slices will be ordered and plotted counter-clockwise.
labels=[]
for i in range(1,nrows):
    labels.insert(i-1,sheet.cell_value(i, 0))
sizes=[]
for i in range(1,nrows):
    sizes.insert(i-1,sheet.cell_value(i, 1))


#colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral','red']
#explode = (0, 0.1, 0, 0,0)  # only "explode" the 2nd slice (i.e. 'Hogs')

plt.pie(sizes,  labels=labels,
        autopct='%1.1f%%', shadow=True, startangle=90)

# Set aspect ratio to be equal so that pie is drawn as a circle.
#plt.axis("")

#plt.show()
tablename=sheet_list[0]
ax.set_title(tablename)

plt.savefig(url)