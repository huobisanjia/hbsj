﻿# -*- coding: utf-8 -*-
import sys
default_encoding = 'utf-8'
if sys.getdefaultencoding() != default_encoding:
      reload(sys)
      sys.setdefaultencoding(default_encoding)

for i in range(1, len(sys.argv)):
     url = sys.argv[1]
     excalurl=sys.argv[2]
    

import matplotlib.pyplot as plt
plt.rcdefaults()
import numpy as np



plt.rcdefaults()
fig, ax = plt.subplots()
from pylab import *
mpl.rcParams['font.sans-serif'] = ['SimHei']
# 导入xlrd模块
import xlrd
# 设置文件名和路径
fname =excalurl
# 打开文件
filename = xlrd.open_workbook(fname)
sheets = filename.nsheets
# 得到的是一个列表集合[u'etsy_sheet']
sheet_list = filename.sheet_names()
tablename=sheet_list[0]
sheet = filename.sheets()[0]  # 通过sheet索引获得sheet对象
print sheet
# 获取行数
nrows = sheet.nrows
print nrows
# 获取列数
ncols = sheet.ncols
# Example data
people=[]
for i in range(1,nrows):
    people.insert(i-1,sheet.cell_value(i, 0))
y_pos = np.arange(len(people))
performance=[]
for i in range(1,nrows):
    performance.insert(i-1,int(sheet.cell_value(i, 1)))
error = np.random.rand(len(people))

ax.barh(y_pos, performance, xerr=error, align='center',
        color='pink', ecolor='black')
ax.set_yticks(y_pos)
ax.set_yticklabels(people)
ax.invert_yaxis()  # labels read top-to-bottom
#ax.set_xlabel('Performance')
ax.set_title(tablename)

#uipath = unicode(asd , "utf8")

plt.savefig(url)