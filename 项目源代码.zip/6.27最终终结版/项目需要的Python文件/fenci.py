﻿# encoding=utf-8
import jieba
import sys
default_encoding = 'utf-8'
if sys.getdefaultencoding() != default_encoding:
      reload(sys)
      sys.setdefaultencoding(default_encoding)

for i in range(1, len(sys.argv)):
     url = sys.argv[1]

seg_list = jieba.cut_for_search(url)  # 搜索引擎模式
name=" ".join(seg_list)
name1=name.encode('utf-8')  
name2=name1.decode('utf-8')  
name3=name2.encode('gbk')  
#name4=name3.decode('gbk')#http://blog.sina.com.cn/s/blog_13ea9a2450102xb84.html
#print(name)  
#print(type(name3))  
print(name3)



