package com.hbsj.evaluate.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.hbsj.entity.Computereasy;
import com.hbsj.entity.Evaluate;
@Repository
public class EvaluateDaoImpl {
	@Resource
	private SessionFactory sessionFactory;

	public List<Evaluate> selectByCpId(int CpId) {

		try {
			List<Evaluate> list = this.sessionFactory.getCurrentSession().createQuery("from Evaluate e where e.cpId=?").setParameter(0,CpId).list();
			
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
}
	public List<Evaluate> selectByPage(int CpNumber,int pageNum,int pageSize){
		
		try{
			Query query=this.sessionFactory.getCurrentSession().createQuery("from "+Evaluate.class.getSimpleName());
			query.setFirstResult((pageNum-1)*pageSize);
			query.setMaxResults(pageSize);
			return query.list();
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		
	}
}
