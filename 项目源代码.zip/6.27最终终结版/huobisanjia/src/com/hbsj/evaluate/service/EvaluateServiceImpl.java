package com.hbsj.evaluate.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hbsj.entity.Evaluate;
import com.hbsj.entity.Page;
import com.hbsj.evaluate.dao.EvaluateDaoImpl;


@Service
@Transactional
public class EvaluateServiceImpl {
	@Resource
	private EvaluateDaoImpl edi;
	//输入商品编号  页数 页大小 返回page
	public Page<Evaluate> selectByCpNumber(int CpNumber,int pageNum,int pageSize){
		
		try {
			List<Evaluate> list =this.edi.selectByCpId(CpNumber);
			Page<Evaluate> page = new Page<Evaluate>(pageNum,pageSize);
			page.setList(this.edi.selectByPage(CpNumber, pageNum, pageSize));
			page.setTotalCount(list.size());

			return page;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
}
