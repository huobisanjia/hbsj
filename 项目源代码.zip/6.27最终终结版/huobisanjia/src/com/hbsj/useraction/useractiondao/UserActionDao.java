package com.hbsj.useraction.useractiondao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.hbsj.entity.useraction;

@Repository
public class UserActionDao {
	@Resource
	private SessionFactory sessionFactory;
	
	public List<useraction> findByUserId(int id){
		System.out.println("****************"+id+"**********wozaidao*****************");
		List<useraction> list= this.sessionFactory.getCurrentSession().createQuery("from useraction ua where ua.userid=?").setParameter(0, id).list();
		System.out.println(list.size()+"zhelishi list size");
		return list;
		
	}
}
