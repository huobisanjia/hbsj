package com.hbsj.useraction.useractionservice;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hbsj.entity.Computereasy;
import com.hbsj.entity.useraction;
import com.hbsj.product.dao.ProductDaoImpl;
import com.hbsj.useraction.useractiondao.UserActionDao;

@Service
@Transactional
public class UserActionService {
	@Resource
	private UserActionDao uad;
	@Resource
	private ProductDaoImpl psii;
	public List<useraction> SelectBydayAction(int id,int day) throws ParseException{
		List<useraction> list = new ArrayList<useraction>();
		SimpleDateFormat sdf = new SimpleDateFormat
  				("yyyy-MM-dd hh:mm:ss"); 
 		Date d1 = new Date();
 		if(day==1) {
 			for(int i =0;i<this.uad.findByUserId(id).size();i++) {
 	 			String d2 = this.uad.findByUserId(id).get(i).getregistTime();
 	 			long m = d1.getTime() - sdf.parse(d2).getTime();

 	 			
 	 			if(m/(1000 * 60 * 60 * 24)<1) {
 	 				int count=0;
 	 				for(int j=0;j<list.size();j++){
 	 					
 	 					if(list.get(j).getProductid()==this.uad.findByUserId(id).get(i).getProductid()){
 	 						count++;
 	 					}
 	 				}
 	 				if(count==0){
 	 					list.add(this.uad.findByUserId(id).get(i));
 	 				}
 
 	 				
 	 			}
 	 		
 	 			
 	 		}
 		}if(day==3) {
 			for(int i =0;i<this.uad.findByUserId(id).size();i++) {
 	 			String d2 = this.uad.findByUserId(id).get(i).getregistTime();
 	 			long m = d1.getTime() - sdf.parse(d2).getTime();
 	 			System.out.println(d1.getTime());
 	 			System.out.println(sdf.parse(d2).getTime());
 	 			System.out.println(m/(1000 * 60 * 60 * 24));
 	 			if(m/(1000 * 60 * 60 * 24)>=2&&m/(1000 * 60 * 60 * 24)<=3) {
 	 				int count=0;
 	 				for(int j=0;j<list.size();j++){
 	 					
 	 					if(list.get(j).getProductid()==this.uad.findByUserId(id).get(i).getProductid()){
 	 						count++;
 	 					}
 	 				}
 	 				if(count==0){
 	 					list.add(this.uad.findByUserId(id).get(i));
 	 				}
 	 			}
 	 		}
 		}
 		if(day==7) {
 			for(int i =0;i<this.uad.findByUserId(id).size();i++) {
 	 			String d2 = this.uad.findByUserId(id).get(i).getregistTime();
 	 			long m = d1.getTime() - sdf.parse(d2).getTime();
 	 			if(m/(1000 * 60 * 60 * 24)>=4&&m/(1000 * 60 * 60 * 24)<=7) {
 	 				int count=0;
 	 				for(int j=0;j<list.size();j++){
 	 					
 	 					if(list.get(j).getProductid()==this.uad.findByUserId(id).get(i).getProductid()){
 	 						count++;
 	 					}
 	 				}
 	 				if(count==0){
 	 					list.add(this.uad.findByUserId(id).get(i));
 	 				}
 	 			}
 	 		}
 		}
  		
		return list;
		
	}

}
