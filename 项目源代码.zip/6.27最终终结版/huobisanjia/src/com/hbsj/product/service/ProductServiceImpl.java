package com.hbsj.product.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hbsj.entity.Computer;
import com.hbsj.entity.Computereasy;
import com.hbsj.entity.Computermid;
import com.hbsj.entity.Page;
import com.hbsj.product.dao.ProductDaoImpl;

@Service
@Transactional
public class ProductServiceImpl {
	@Resource
	private ProductDaoImpl pdi;
	

	
	
	public Page<Computereasy> selectByPage(int pageNum, int pageSize) {
		Page<Computereasy> page = new Page<Computereasy>(pageNum,pageSize);
		page.setList(this.pdi.findByPage(pageNum, pageSize));
		page.setTotalCount(this.pdi.findAll().size());
		return page;
		
	}
	public Computereasy selectCmpbycpNumber(int cpNumber) {
		return pdi.selexctCmpbycN(cpNumber);
	}
	public Computereasy selecteasy(int cpNumber) {
		return pdi.selectEasyById(cpNumber);
	}
	public Computer selectp(int cpNumber) {
		return pdi.selectById(cpNumber);
	}
	
}
