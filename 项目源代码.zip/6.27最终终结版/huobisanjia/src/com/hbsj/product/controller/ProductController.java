package com.hbsj.product.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import org.hibernate.Session;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hbsj.entity.Computer;
import com.hbsj.entity.Computereasy;
import com.hbsj.entity.Computermid;
import com.hbsj.entity.Page;
import com.hbsj.entity.User;
import com.hbsj.entity.useraction;
import com.hbsj.evaluate.service.EvaluateServiceImpl;
import com.hbsj.product.dao.ProductDaoImpl;
import com.hbsj.product.service.ProductServiceImpl;
import com.hbsj.user.dao.UserDao;



@Controller
@RequestMapping("/product")
public class ProductController {
	@Resource
	private ProductServiceImpl psi;
	@Resource
	private ProductDaoImpl psii;
	@Resource
	private EvaluateServiceImpl esi;

	
	
	@RequestMapping(value="/compare",method=RequestMethod.GET)
	public String computerCompare(Model model, HttpSession session) {
		if(session.getAttribute("ProductList")!=null||session.getAttribute("ProductEasyList")!=null) {
			session.removeAttribute("ProductList");
			session.removeAttribute("ProductEasyList");
		}
		List<Computereasy> list = (List<Computereasy>) session.getAttribute("listcompare");
		List<Computer> clist = new ArrayList<Computer>();
		List<Computereasy> celist = new ArrayList<Computereasy>();
		for(int i=0;i<list.size();i++) {
			clist.add(this.psi.selectp(list.get(i).getCpNumber()));
			celist.add(this.psi.selecteasy(list.get(i).getCpNumber()));
		}

		model.addAttribute("ProductEasyList",celist);
		model.addAttribute("ProductList",clist);
		System.out.println("***************************");
		System.out.println(clist.size());
		return "compare";
		
	}
	//删除对比框某元素
		@RequestMapping(value="/deletecompare",method=RequestMethod.GET)
		public String computerDeleteCompare(@RequestParam("cpNumber1") int id1,Model model, HttpSession session,
				@RequestParam("pageSize") int pageSize,
				@RequestParam("pageNum") int pageNum) {

			List<Computereasy>  listcompare=(List<Computereasy>) session.getAttribute("listcompare");
			for(int i=0;i<listcompare.size();i++) {
				if(listcompare.get(i).getCpNumber()==id1) {
					listcompare.remove(i);
				}
			}
			session.removeAttribute("listcompare");
			session.setAttribute("listcompare", listcompare);
			model.addAttribute("page", psi.selectByPage(pageNum, pageSize));
			return "search";
			
		}
		//清空对比框
		@RequestMapping(value="/removecompare",method=RequestMethod.GET)
		public String computerRemoveCompare(Model model, HttpSession session,
				@RequestParam("pageSize") int pageSize,
				@RequestParam("pageNum") int pageNum) {
			session.removeAttribute("listcompare");
			model.addAttribute("page", psi.selectByPage(pageNum, pageSize));
			return "search";
			
		}
	@RequestMapping(value="/addcompare",method=RequestMethod.GET)
	public String computerAddCompare(@RequestParam("cpNumber1") int id1,Model model, HttpSession session,
			@RequestParam("pageSize") int pageSize,
			@RequestParam("pageNum") int pageNum) {
		
		
		if(session.getAttribute("listcompare")==null) {
			List<Computereasy>  listcompare = new ArrayList<Computereasy>();
			Computereasy ce = this.psi.selecteasy(id1);
			listcompare.add(ce);
			session.setAttribute("listcompare", listcompare);
		}else {
			List<Computereasy>  listcompare=(List<Computereasy>) session.getAttribute("listcompare");
			Computereasy ce = this.psi.selecteasy(id1);
			int count =0;
			for(int i=0;i<listcompare.size();i++) {
				if(listcompare.get(i).getCpName().equals(ce.getCpName())) {
					count++;
				}
			}
			if(count==0) {
				listcompare.add(ce);
				session.setAttribute("listcompare", listcompare);
			}else {
				model.addAttribute("page", psi.selectByPage(pageNum, pageSize));
				return "search";
			}
			
		}
		model.addAttribute("page", psi.selectByPage(pageNum, pageSize));
		return "search";
		
	}
	
	@RequestMapping(value="/display",method=RequestMethod.GET)
	public String computerDisplay(@RequestParam("pageSize") int pageSize,
			@RequestParam("pageNum") int pageNum,
			Model model) {

			model.addAttribute("page", psi.selectByPage(pageNum, pageSize));
			return "search";	
	}
	@RequestMapping(value="/listProductDescription",method=RequestMethod.GET)
	public String listProductDescription(@RequestParam("cpNumber") int cpNumber,@RequestParam("evPageNum") int evPageNum,
			Model model,HttpSession session) {
		
		Computereasy p=this.psi.selecteasy(cpNumber);
		if (session.getAttribute("userid")==null){
		JOptionPane.showMessageDialog(null, "请先登录");
		return "login";
	}
		if(null!=session.getAttribute("userid")) {
			try {
				String datetime=(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")).format(Calendar.getInstance().getTime());
				Object obj=session.getAttribute("userid");
				int userid=Integer.parseInt(obj.toString());
				useraction uaction=new useraction();
				uaction.setProductid(cpNumber);
				uaction.setCpImgAdress(p.getCpImgAdress());
				uaction.setProductname(p.getCpName());
				uaction.setPrice(p.getPrice());
				uaction.setregistTime(datetime);
				uaction.setuserid(userid);
				this.psii.adduseraction(uaction);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		model.addAttribute("evapage",esi.selectByCpNumber(cpNumber, evPageNum, 12));

		model.addAttribute("pro", psii.selexctmid(cpNumber));
		model.addAttribute("p", psi.selecteasy(cpNumber));
		model.addAttribute("pl",psi.selectp(cpNumber));
		
		return "introducton";
		
	}
	@RequestMapping(value="/searchdisplay")
	public String computersearch(HttpServletRequest request,@RequestParam("search") String search,Model model) {
		System.out.println("搜索"+search);
		//Runtime.getRuntime();
		String[] array=search.split(" ");
		Collection<Computereasy> list = new ArrayList();
		Page<Computereasy> page = new Page<Computereasy>();
		for (int i = 0; i <array.length; i++) {
			Collection<Computereasy> list0 = psii.search(array[i]);
			System.out.println("搜索search[]"+i+array[i]+"size:"+list0.size());
			list.addAll(list0);
			
		}
		List newList = new ArrayList(new HashSet(list));
		int pageSize=20;
		
		String pageNum = request.getParameter("pageNum");
		System.out.println("pageNum"+pageNum);
		int num = 1;
		if (pageNum == null || pageNum.equals("")) {
			num = 1;
			page.setCurrentPageNum(num);
			
		} else {
			num = Integer.parseInt(pageNum);
			page.setCurrentPageNum(num);
		}
		
		List<Computereasy> subList = null ;
		
		if(num<newList.size()/20){        //默认舍去小数部分
		 subList = newList.subList(pageSize*num-20, pageSize*num);
		}
		else {
			subList = newList.subList(pageSize*num-20, newList.size());
		}
		
		page.setList(subList);
		page.setPageSize(20);
		page.setTotalCount(newList.size());
		
		model.addAttribute("page", page);
		model.addAttribute("search", search);
		System.out.println("num::"+num);
	
		//return "search";
		return "sousuo";
		
	}

}
