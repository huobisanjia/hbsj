package com.hbsj.product.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import com.hbsj.entity.Computer;
import com.hbsj.entity.Computereasy;
import com.hbsj.entity.Computermid;
import com.hbsj.entity.useraction;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

@Repository
public class ProductDaoImpl {
	@Resource
	private SessionFactory sessionFactory;
	
	public Computer selectById(int id) {

		try {
			Computer cp=(Computer) this.sessionFactory.getCurrentSession().createQuery("from Computer c where c.cpNumber=?").setParameter(0,id).uniqueResult();
			return cp;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		

		
		
	}
	
	public Computereasy selectEasyById(int id) {

		try {
			Computereasy cpe=(Computereasy) this.sessionFactory.getCurrentSession().createQuery("from Computereasy c where c.cpNumber=?").setParameter(0,id).uniqueResult();
			return cpe;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		

		
		
	}

	public List<Computereasy> findAll(){
		try {
			List<Computereasy> list = this.sessionFactory.getCurrentSession().createQuery("from Computereasy").list();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		
	}
	public void adduseraction(useraction useraction) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(useraction);
		tx.commit();
		session.close();
	

	}
	
	public List<Computermid> ComputermidfindByPage(int pageNum, int pageSize){
		try{
			Query query=this.sessionFactory.getCurrentSession().createQuery("from "+Computermid.class.getSimpleName());
			query.setFirstResult((pageNum-1)*pageSize);
			query.setMaxResults(pageSize);
			return query.list();
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	public List<Computermid> Computermidfindcount(){
		try{
			Query query=this.sessionFactory.getCurrentSession().createQuery("from "+Computereasy.class.getSimpleName());
			
			return query.list();
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public List<Computereasy> findByPage(int pageNum, int pageSize){
		try{
			Query query=this.sessionFactory.getCurrentSession().createQuery("from "+Computereasy.class.getSimpleName());
			query.setFirstResult((pageNum-1)*pageSize);
			query.setMaxResults(pageSize);
			return query.list();
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	public Computereasy selexctCmpbycN(int cpNumber) {
		try {
			Computereasy cpe=(Computereasy) this.sessionFactory.getCurrentSession().createQuery("from Computereasy c where c.cpNumber=?").setParameter(0,cpNumber).uniqueResult();
			return cpe;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public Computermid selexctmid(int cpNumber) {
		try {
			Computermid cpe=(Computermid) this.sessionFactory.getCurrentSession().createQuery("from Computermid c where c.cpNumber=?").setParameter(0,cpNumber).uniqueResult();
			return cpe;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public List<Computereasy> search(String bran){
		try {
			
			Session session = this.sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			String hql = "from Computereasy c where c.cpName like:brand";
			Query query = session.createQuery(hql);
			query.setString("brand", "%"+bran+"%");
			List<Computereasy> list = query.list();
			
			tx.commit();
			session.close();
			return list;
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		
	}
	public List findpricefrommid() {
		try {
			 List list=this.sessionFactory.getCurrentSession().createQuery("select cmid.price from Computermid cmid").list();
			 
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public List findleixingfrommid() {
		try {
			 List list=this.sessionFactory.getCurrentSession().createQuery("select cmid.brand from Computermid cmid").list();
			 
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public List findshopmamefrommid() {
		try {
			 List list=this.sessionFactory.getCurrentSession().createQuery("select cmid.businesses from Computermid cmid").list();
			 
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public void addproduct(Computermid Computermid) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(Computermid);
		tx.commit();
		session.close();
		

	}
}
