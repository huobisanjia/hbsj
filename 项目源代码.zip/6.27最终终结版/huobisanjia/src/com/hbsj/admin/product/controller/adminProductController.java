package com.hbsj.admin.product.controller;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;  
import org.apache.poi.ss.usermodel.Cell;  
import org.apache.poi.ss.usermodel.Row;  
import org.apache.poi.ss.usermodel.Sheet;  
import org.apache.poi.ss.usermodel.Workbook; 
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.hbsj.cart.dao.cartDao;
import com.hbsj.entity.Computer;
import com.hbsj.entity.Computereasy;
import com.hbsj.entity.Computermid;
import com.hbsj.entity.Page;
import com.hbsj.entity.User;
import com.hbsj.evaluate.service.EvaluateServiceImpl;
import com.hbsj.product.dao.ProductDaoImpl;
import com.hbsj.product.service.ProductServiceImpl;
import com.hbsj.user.dao.UserDao;


@Controller
@RequestMapping("/adminproduct")
public class adminProductController {
	

	@Resource
	private EvaluateServiceImpl esi;
	@RequestMapping(value="/postaddProduct")
	public String postaddProduct(@RequestParam(value="pinpai") String pinpai,@RequestParam(value="xiaoshouchang") String xiaoshouchang,@RequestParam(value="leixing") String leixing,
			@RequestParam(value="price") String price,@RequestParam(value="shangshitime") String shangshitime,@RequestParam(value="pingmusize") String pingmusize, @RequestParam(value="cpu") String cpu,@RequestParam(value="img1") MultipartFile fileimg1,HttpServletRequest request,Model model) {
		String rootPath=request.getServletContext().getRealPath("/admin");
		System.out.print(rootPath);
		//String  fileimg1Name=new Date().getTime()+fileimg1.getOriginalFilename().substring(fileimg1.getOriginalFilename().lastIndexOf("."), fileimg1.getOriginalFilename().length());
		String  fileimg1Name="aa";
		if(!fileimg1.isEmpty()){
			try {
				InputStream is=fileimg1.getInputStream();
				FileOutputStream fos=new FileOutputStream(
						rootPath+"/"+"images/"
						+fileimg1Name);
				int len=0;
				byte []cache=new byte[is.available()];
				while((len=is.read(cache))>0){
				fos.write(cache,0,len);
				}
				is.close();
				fos.flush();
				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		//保存数据
		Computermid p=new Computermid();
		p.setBrand(pinpai);
		p.setBusinesses(xiaoshouchang);
		p.setProducttype(leixing);
		p.setPrice(price);
		p.setMarkettime(shangshitime);
		p.setScreensize(pingmusize);
		p.setCpu(cpu);
	    //int Price=Integer.parseInt(objprice.toString());
		p.setRating("images/"+fileimg1.getOriginalFilename());
	    p.setGraphics("核心显卡");
	    p.setCpName("苹果(Apple) MacBook Air MQD42CH/A 13.3英寸笔记本电脑 I5处理器/8G/256GSSD/集显");
	    
	    this.psii.addproduct(p);
		
		return "admin/addproduce";
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping(value="/adminproduct")
	public String computeradminproduct(@RequestParam("pageNum") String pageNum,HttpServletRequest request,Model model, HttpSession session) {
		//String pageNum = request.getParameter("pageNum");
		Page<Computermid> page = new Page<Computermid>();
		int num = 1;
		if (pageNum == null || pageNum.equals("")) {
			num = 1;
			page.setCurrentPageNum(num);
			
		} else {
			num = Integer.parseInt(pageNum);
			page.setCurrentPageNum(num);
		}
		int pageSize=20;
		List<Computermid> countmid=psii.Computermidfindcount();
		List<Computermid> listmid=psii.ComputermidfindByPage(num, pageSize);
		page.setList(listmid);
		page.setPageSize(pageSize);
		page.setTotalCount(countmid.size());
		model.addAttribute("page", page);
		
		System.out.println("num::"+num);
	
		
		return "admin/order_list";
	}
	
	
	
	
	@Resource
	private ProductServiceImpl psi;
	@Resource
	private ProductDaoImpl psii;
	@RequestMapping(value="/adminpricetu")
	public String computerCompare(Model model, HttpSession session,HttpServletRequest request) {
		    List  resultlist = new ArrayList();
		    int j=0;
		    int k=0;
		    int l=0;
		    int p=0;
		    int q=0;
		    int y=0;
		    List pricelist=this.psii.findpricefrommid();
			 for(int i=0;i<pricelist.size();i++)    {
				 System.out.print(pricelist.get(i));
		            if(pricelist.get(i).equals("")||pricelist.get(i).equals("暂无报价")){
		              j++;
		            }else{
		            	
		              if(Integer.parseInt((String) pricelist.get(i))>0&&Integer.parseInt((String) pricelist.get(i))<3000){
		            	  k++;
		              }
		              if(Integer.parseInt((String) pricelist.get(i))>=3000&&Integer.parseInt((String) pricelist.get(i))<5000){
		            	l++;
		            }
		              if(Integer.parseInt((String) pricelist.get(i))>=5000&&Integer.parseInt((String) pricelist.get(i))<7000){
			            	p++;
			            }
		              if(Integer.parseInt((String) pricelist.get(i))>=7000&&Integer.parseInt((String) pricelist.get(i))<9000){
			            	q++;
			            }
		              if(Integer.parseInt((String) pricelist.get(i))>=9000){
			            	y++;
			            }
		        }
			//model.addAttribute("ProductEasyList",listeasy);
		
			//System.out.print(j);
			//System.out.print(k);
			//System.out.print(l);
	}
			 List biaotou=new ArrayList();         
		     
		     biaotou.add("price");  
		     biaotou.add("geshu");  
		     resultlist.add(biaotou);  
		     
		     List neirong=new ArrayList();  
		     neirong.add("暂无报价");  
		     neirong.add(Integer.toString(j));  
		     resultlist.add(neirong);  
		     
		     neirong=new ArrayList();//初始化一下，这样之前的值就不会加入  
		     neirong.add("0~3000");  
		     neirong.add(Integer.toString(k));  
		     resultlist.add(neirong);  
		     neirong=new ArrayList();  
		     neirong.add("3000~5000");  
		     neirong.add(Integer.toString(l));  
		     resultlist.add(neirong);   
		     
		     neirong=new ArrayList();  
		     neirong.add("5000~7000");  
		     neirong.add(Integer.toString(p));  
		     resultlist.add(neirong);
		     
		     neirong=new ArrayList();  
		     neirong.add("7000~9000");  
		     neirong.add(Integer.toString(q));  
		     resultlist.add(neirong);
		     
		     neirong=new ArrayList();  
		     neirong.add(">9000");  
		     neirong.add(Integer.toString(y));  
		     resultlist.add(neirong);
		     System.out.print(resultlist);
		     String excalurl="d:\\pricezhu.xls";
		     //String excalurl="/root/pricezhu.xls";
		     String tablename="价格区间与相应数量柱状图";
		     try {
				writeToXls(resultlist, excalurl,tablename);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		    String rootPath=request.getServletContext().getRealPath("/admin/images/htw.jpg");
			System.out.print(rootPath);
		     String url=rootPath;
		    
		    //String[] asd = new String[] { "python", "/root/htjavazhu.py" ,url,excalurl};
           String[] asd = new String[] { "python", "D:\\eclip\\javatopy\\htjavazhu.py",url,excalurl };
		     javatopy(asd ,excalurl);
		     
		     
		     
		     
		     List  resultlist1 = new ArrayList();
			    int j1=0;
			    int k1=0;
			    int l1=0;
			    int p1=0;
			    int q1=0;
			    int y1=0;
			    int we=0;
			    List pricelist1=this.psii.findleixingfrommid();
				 for(int i=0;i<pricelist1.size();i++)    {
			            if(pricelist1.get(i).equals("ThinkPad笔记本电脑")){
			              j1++;
			            }else{
			            	if(pricelist1.get(i).equals("联想笔记本电脑")){
			            		k1++;
			              }
			            	if(pricelist1.get(i).equals("惠普笔记本电脑")){
			            	l1++;
			            }
			            	if(pricelist1.get(i).equals("华硕笔记本电脑")){
				            	p1++;
				            }
			            	if(pricelist1.get(i).equals("苹果笔记本电脑")){
				            	q1++;
				            }
			            	if(pricelist1.get(i).equals("神舟笔记本电脑")){
				            	y1++;
				            }
			            	if(pricelist1.get(i).equals("微星笔记本电脑")){
				            	we++;
				            }
			        }
				//model.addAttribute("ProductEasyList",listeasy);
			
				//System.out.print(j);
				//System.out.print(k);
				//System.out.print(l);
		}
				 List biaotou1=new ArrayList();         
			     
			     biaotou1.add("leixing");  
			     biaotou1.add("geshu");  
			     resultlist.add(biaotou1);  
			     
			     List neirong1=new ArrayList();  
			     neirong1.add("ThinkPad笔记本电脑");  
			     neirong1.add(Integer.toString(j1));  
			     resultlist1.add(neirong1);  
			     
			     neirong1=new ArrayList();//初始化一下，这样之前的值就不会加入  
			     neirong1.add("联想笔记本电脑");  
			     neirong1.add(Integer.toString(k1));  
			     resultlist1.add(neirong1);  
			     neirong1=new ArrayList();  
			     neirong1.add("惠普笔记本电脑");  
			     neirong1.add(Integer.toString(l1));  
			     resultlist1.add(neirong1);   
			     
			     neirong1=new ArrayList();  
			     neirong1.add("华硕笔记本电脑");  
			     neirong1.add(Integer.toString(p1));  
			     resultlist1.add(neirong1);
			     
			     neirong1=new ArrayList();  
			     neirong1.add("苹果笔记本电脑");  
			     neirong1.add(Integer.toString(q1));  
			     resultlist1.add(neirong1);
			     
			     neirong1=new ArrayList();  
			     neirong1.add("神舟笔记本电脑");  
			     neirong1.add(Integer.toString(y1));  
			     resultlist1.add(neirong1);
			     
			     neirong1=new ArrayList();  
			     neirong1.add("微星笔记本电脑");  
			     neirong1.add(Integer.toString(we));  
			     resultlist1.add(neirong1);
			     System.out.print(resultlist1);
			     String excalurl1="d:\\leixingzhu.xls";
			     //String excalurl1="/root/leixingzhu.xls";
			     String tablename1="品牌饼图";
			     try {
					writeToXls(resultlist1, excalurl1,tablename1);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			     
			    String rootPath1=request.getServletContext().getRealPath("/admin/images/htyuanbing.jpg");
				System.out.print(rootPath1);
			     String url1=rootPath1;
			     //url:python存放文件的位置 
			    // String tablename1="aa";
			    //String[] asd1 = new String[] { "python", "/root/htjavabing.py" ,url1,excalurl1};
	            String[] asd1 = new String[] { "python", "D:\\eclip\\javatopy\\htjavabing.py",url1,excalurl1 };
			     javatopy(asd1 ,excalurl);
			         
		     
		     
		     
			     List  resultlist11 = new ArrayList();
			        int kong=0;
				    int j11=0;
				    int k11=0;
				    int l11=0;
				    int p11=0;
				    int q11=0;
				    int y11=0;
				    int we1=0;
				    List pricelist11=this.psii.findshopmamefrommid();
					 for(int i=0;i<pricelist11.size();i++)    {
						 if(pricelist11.get(i)==null){
				              kong++;
				            
				            }else{
				            	if(pricelist11.get(i).equals("(国美 第三方)")||pricelist11.get(i).equals("(国美 自营)")){
						              j11++;
						              }
				            	
				            	if(pricelist11.get(i).equals("(苏宁易购 第三方)")||pricelist11.get(i).equals("(苏宁易购 自营)")){
				            		k11++;
				              }
				            	if(pricelist11.get(i).equals("(京东商城 自营)")){
				            	l11++;
				            }
				            	if(pricelist11.get(i).equals("(中国亚马逊 )")){
					            	p11++;
					            }
				            	if(((String) pricelist11.get(i)).contains("天猫")){
					            	q11++;
					           
				            	if(pricelist11.get(i).equals("(顺电网 自营)")){
					            	y11++;
					            }
				            	
				        }
					//model.addAttribute("ProductEasyList",listeasy);
				
					//System.out.print(j);
					//System.out.print(k);
					//System.out.print(l);
			}
					 }
					 List biaotou11=new ArrayList();         
				     
				     biaotou11.add("shopname");  
				     biaotou11.add("geshu");  
				     resultlist11.add(biaotou11);  
				     
				     List neirong11=new ArrayList();  
				     neirong11.add("国美");  
				     neirong11.add(Integer.toString(j11));  
				     resultlist11.add(neirong11);  
				     
				     neirong11=new ArrayList();//初始化一下，这样之前的值就不会加入  
				     neirong11.add("苏宁易购");  
				     neirong11.add(Integer.toString(k11));  
				     resultlist11.add(neirong11);  
				     neirong11=new ArrayList();  
				     neirong11.add("京东");  
				     neirong11.add(Integer.toString(l11));  
				     resultlist11.add(neirong11);   
				     
				     neirong11=new ArrayList();  
				     neirong11.add("中国亚马逊 ");  
				     neirong11.add(Integer.toString(p11));  
				     resultlist11.add(neirong11);
				     
				     neirong11=new ArrayList();  
				     neirong11.add("天猫");  
				     neirong11.add(Integer.toString(q11));  
				     resultlist11.add(neirong11);
				     
				     neirong11=new ArrayList();  
				     neirong11.add("顺电网");  
				     neirong11.add(Integer.toString(y11));  
				     resultlist11.add(neirong11);
				     
				    
				     System.out.print(resultlist11);
				     String excalurl11="d:\\shopnamezhe.xls";
				     //String excalurl11="/root/shopnamezhe.xls";
				     String tablename11="商家分布柱状图";
				     try {
						writeToXls(resultlist11, excalurl11,tablename11);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				     
				    String rootPath11=request.getServletContext().getRealPath("/admin/images/htzhexian.jpg");
					System.out.print(rootPath11);
				     String url11=rootPath11;
				     //url:python存放文件的位置 
				    // String tablename1="aa";
				    //String[] asd11 = new String[] { "python", "/root/htzhexian.py",url11,excalurl11};
		            String[] asd11 = new String[] { "python", "D:\\eclip\\javatopy\\htzhexian.py",url11,excalurl11 };
				     javatopy(asd11 ,excalurl1);
				             
	                return "admin/adminindex";
		}
			 
	
	@Resource
	private cartDao cd;
	@RequestMapping(value="/shoucang")
	public String adminusershoucang(Model model, HttpSession session,HttpServletRequest request) {
		
		 
		   
		 List<Integer> useridlist=cd.finduseridfromcart();  
			 
		 Map<Integer, Integer> map = new HashMap<Integer, Integer>();
			for (int item : useridlist) {
			if (map.containsKey(item)) {
			map.put(item, map.get(item) + 1);
			} else {
			map.put(item, new Integer(1));
			}
			}
			Iterator<Integer> keys = map.keySet().iterator();
             List biaotou=new ArrayList();         
             List  resultlist = new ArrayList();
		     biaotou.add("userid");  
		     biaotou.add("geshu");  
		     resultlist.add(biaotou);
			while (keys.hasNext()) {
			
			Integer key = keys.next();
			
			System.out.println(key);
			System.out.println(map.get(key));
			 List neirong=new ArrayList();  
		     neirong.add(Integer.toString(key));  
		     neirong.add(Integer.toString(map.get(key)));  
		     resultlist.add(neirong);
			
			}
		
	         System.out.print(resultlist);
		    String excalurl="d:\\useridshowcangnum.xls";
	         //String excalurl="/root/useridshowcangnum.xls";
		     String tablename="用户ID与收藏商品数量";
		     try {
				writeToXls(resultlist, excalurl,tablename);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		    String rootPath=request.getServletContext().getRealPath("/admin/images/htwusershowcangid.jpg");
			System.out.print(rootPath);
		     String url=rootPath;
		    
		    //String[] asd = new String[] { "python", "/root/htjavazhu.py",url,excalurl };
         String[] asd = new String[] { "python", "D:\\eclip\\javatopy\\htjavazhu.py",url,excalurl };
		     javatopy(asd ,excalurl);
		     
		     
		     
		     
		     
		     
		     
		     
		     
		     
		     
		     List<Integer> productid=cd.findproudtidfromcart();
			 
			 Map<Integer, Integer> map1 = new HashMap<Integer, Integer>();
				for (int item : useridlist) {
				if (map1.containsKey(item)) {
				map1.put(item, map1.get(item) + 1);
				} else {
				map1.put(item, new Integer(1));
				}
				}
				Iterator<Integer> keys1 = map.keySet().iterator();
	             List biaotou1=new ArrayList();         
	             List  resultlist1 = new ArrayList();
			     biaotou1.add("produceid");  
			     biaotou1.add("geshu");  
			     resultlist1.add(biaotou1);
				while (keys1.hasNext()) {
				
				Integer key = keys1.next();
				
				System.out.println(key);
				System.out.println(map.get(key));
				 List neirong=new ArrayList();  
			     neirong.add(Integer.toString(key));  
			     neirong.add(Integer.toString(map.get(key)));  
			     resultlist1.add(neirong);
				
				}
			
		         System.out.print(resultlist);
			     String excalurl1="d:\\productidangshowcnum.xls";
		         //String excalurl1="/root/productidangshowcnum.xls";
			     String tablename1="商品ID与收藏次数";
			     try {
					writeToXls(resultlist1, excalurl1,tablename1);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			     
			    String rootPath1=request.getServletContext().getRealPath("/admin/images/htwproductshowcangid.jpg");
				System.out.print(rootPath1);
			     String url1=rootPath1;
			    
			    //String[] asd1= new String[] { "python", "/root/htzhexian.py",url1,excalurl1 };
	         String[] asd1 = new String[] { "python", "D:\\eclip\\javatopy\\htzhexian.py",url1,excalurl1 };
			     javatopy(asd1 ,excalurl1);
			     
			      
		
			     
			     
			     
			     
			     List  resultlist11 = new ArrayList();
				 
				    int k=0;
				    int l=0;
				    int p=0;
				    int q=0;
				    int y=0;
				    List <Double>pricelist=cd.findpricefromcart();
					 for(int i=0;i<pricelist.size();i++)    {
				
				              if( pricelist.get(i)>0&&pricelist.get(i)<3000){
				            	  k++;
				              }else{
				                if( pricelist.get(i)>=3000&& pricelist.get(i)<5000){
				            	l++;
				            }
				              if(pricelist.get(i)>=5000&& pricelist.get(i)<7000){
					            	p++;
					            }
				              if( pricelist.get(i)>=7000&&pricelist.get(i)<9000){
					            	q++;
					            }
				              if(pricelist.get(i)>=9000){
					            	y++;
					            }
				        }
					//model.addAttribute("ProductEasyList",listeasy);
				
					//System.out.print(j);
					//System.out.print(k);
					//System.out.print(l);
			}
					 List biaoto11=new ArrayList();         
				     
				     biaoto11.add("price");  
				     biaoto11.add("geshu");  
				     resultlist11.add(biaoto11);  
				     
				     List neirong11=new ArrayList();  
				   
				     
				     neirong11=new ArrayList();//初始化一下，这样之前的值就不会加入  
				     neirong11.add("0~3000");  
				     neirong11.add(Integer.toString(k));  
				     resultlist11.add(neirong11);  
				     neirong11=new ArrayList();  
				     neirong11.add("3000~5000");  
				     neirong11.add(Integer.toString(l));  
				     resultlist11.add(neirong11);   
				     
				     neirong11=new ArrayList();  
				     neirong11.add("5000~7000");  
				     neirong11.add(Integer.toString(p));  
				     resultlist11.add(neirong11);
				     
				     neirong11=new ArrayList();  
				     neirong11.add("7000~9000");  
				     neirong11.add(Integer.toString(q));  
				     resultlist11.add(neirong11);
				     
				     neirong11=new ArrayList();  
				     neirong11.add(">9000");  
				     neirong11.add(Integer.toString(y));  
				     resultlist11.add(neirong11);
				     System.out.print(resultlist11);
				     String excalurl11="d:\\userpricebingtushowcang.xls";
				     //String excalurl11="/root/userpricebingtushowcang.xls";
				     String tablename11="收藏商品价格区间与相应数量饼图";
				     try {
						writeToXls(resultlist11, excalurl11,tablename11);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				     
				    String rootPath11=request.getServletContext().getRealPath("/admin/images/htwusershowcangprice.jpg");
					System.out.print(rootPath11);
				     String url11=rootPath11;
				    
				    //String[] asd11 = new String[] { "python", "/root/htjavabing.py",url11,excalurl11};
		            String[] asd11 = new String[] { "python", "D:\\eclip\\javatopy\\htjavabing.py",url11,excalurl11 };
				     javatopy(asd11 ,excalurl11);
				     
				     
				    
			     
			     
			     
			     
			     
			     
			     
		
		
		
		 return "admin/usershowcang";
	}
	
	@Resource
	private UserDao userdao;
	@RequestMapping(value="/adminuserlook")
	public String adminuserlook(Model model, HttpSession session,HttpServletRequest request) {
		
		 
		   
		 List<Integer> useridlist=userdao.finduseridfromaction();  
			 
		 Map<Integer, Integer> map = new HashMap<Integer, Integer>();
			for (int item : useridlist) {
			if (map.containsKey(item)) {
			map.put(item, map.get(item) + 1);
			} else {
			map.put(item, new Integer(1));
			}
			}
			Iterator<Integer> keys = map.keySet().iterator();
             List biaotou=new ArrayList();         
             List  resultlist = new ArrayList();
		     biaotou.add("userid");  
		     biaotou.add("geshu");  
		     resultlist.add(biaotou);
			while (keys.hasNext()) {
			
			Integer key = keys.next();
			
			System.out.println(key);
			System.out.println(map.get(key));
			 List neirong=new ArrayList();  
		     neirong.add(Integer.toString(key));  
		     neirong.add(Integer.toString(map.get(key)));  
		     resultlist.add(neirong);
			
			}
		
	         System.out.print(resultlist);
		    String excalurl="d:\\useridnum.xls";
		     //String excalurl="/root/useridnum.xls";
		     String tablename="用户ID与登录次数";
		     try {
				writeToXls(resultlist, excalurl,tablename);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		     
		    String rootPath=request.getServletContext().getRealPath("/admin/images/htwuserid.jpg");
			System.out.print(rootPath);
		     String url=rootPath;
		    
		    //String[] asd = new String[] { "python", "/root/htjavazhu.py",url,excalurl };
         String[] asd = new String[] { "python", "D:\\eclip\\javatopy\\htjavazhu.py",url,excalurl };
		     javatopy(asd ,excalurl);
		     
		     
		     
		     
		     
		     
		     
		     
		     
		     
		     
		     List<Integer> productid=userdao.findproudtidfromaction();  
			 
			 Map<Integer, Integer> map1 = new HashMap<Integer, Integer>();
				for (int item : useridlist) {
				if (map1.containsKey(item)) {
				map1.put(item, map1.get(item) + 1);
				} else {
				map1.put(item, new Integer(1));
				}
				}
				Iterator<Integer> keys1 = map.keySet().iterator();
	             List biaotou1=new ArrayList();         
	             List  resultlist1 = new ArrayList();
			     biaotou1.add("produceid");  
			     biaotou1.add("geshu");  
			     resultlist1.add(biaotou1);
				while (keys1.hasNext()) {
				
				Integer key = keys1.next();
				
				System.out.println(key);
				System.out.println(map.get(key));
				 List neirong=new ArrayList();  
			     neirong.add(Integer.toString(key));  
			     neirong.add(Integer.toString(map.get(key)));  
			     resultlist1.add(neirong);
				
				}
			
		         System.out.print(resultlist);
			     String excalurl1="d:\\productidnum.xls";
		         //String excalurl1="/root/productidnum.xls";
			     String tablename1="商品ID与浏览次数";
			     try {
					writeToXls(resultlist1, excalurl1,tablename1);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			     
			    String rootPath1=request.getServletContext().getRealPath("/admin/images/htwproductid.jpg");
				System.out.print(rootPath1);
			     String url1=rootPath1;
			    
			    //String[] asd1 = new String[] { "python", "/root/htzhexian.py",url1,excalurl1 };
	         String[] asd1 = new String[] { "python", "D:\\eclip\\javatopy\\htzhexian.py",url1,excalurl1 };
			     javatopy(asd1 ,excalurl1);
			     
			      
		
			     
			     
			     
			     
			     List  resultlist11 = new ArrayList();
				 
				    int k=0;
				    int l=0;
				    int p=0;
				    int q=0;
				    int y=0;
				    List <Double>pricelist=userdao.findpricefromauserction();
					 for(int i=0;i<pricelist.size();i++)    {
				
				              if( pricelist.get(i)>0&&pricelist.get(i)<3000){
				            	  k++;
				              }else{
				                if( pricelist.get(i)>=3000&& pricelist.get(i)<5000){
				            	l++;
				            }
				              if(pricelist.get(i)>=5000&& pricelist.get(i)<7000){
					            	p++;
					            }
				              if( pricelist.get(i)>=7000&&pricelist.get(i)<9000){
					            	q++;
					            }
				              if(pricelist.get(i)>=9000){
					            	y++;
					            }
				        }
					//model.addAttribute("ProductEasyList",listeasy);
				
					//System.out.print(j);
					//System.out.print(k);
					//System.out.print(l);
			}
					 List biaoto11=new ArrayList();         
				     
				     biaoto11.add("price");  
				     biaoto11.add("geshu");  
				     resultlist11.add(biaoto11);  
				     
				     List neirong11=new ArrayList();  
				   
				     
				     neirong11=new ArrayList();//初始化一下，这样之前的值就不会加入  
				     neirong11.add("0~3000");  
				     neirong11.add(Integer.toString(k));  
				     resultlist11.add(neirong11);  
				     neirong11=new ArrayList();  
				     neirong11.add("3000~5000");  
				     neirong11.add(Integer.toString(l));  
				     resultlist11.add(neirong11);   
				     
				     neirong11=new ArrayList();  
				     neirong11.add("5000~7000");  
				     neirong11.add(Integer.toString(p));  
				     resultlist11.add(neirong11);
				     
				     neirong11=new ArrayList();  
				     neirong11.add("7000~9000");  
				     neirong11.add(Integer.toString(q));  
				     resultlist11.add(neirong11);
				     
				     neirong11=new ArrayList();  
				     neirong11.add(">9000");  
				     neirong11.add(Integer.toString(y));  
				     resultlist11.add(neirong11);
				     System.out.print(resultlist11);
				     String excalurl11="d:\\userpricebingtu.xls";
				    // String excalurl11="/root/userpricebingtu.xls";
				     String tablename11="价格区间与相应数量饼图";
				     try {
						writeToXls(resultlist11, excalurl11,tablename11);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				     
				    String rootPath11=request.getServletContext().getRealPath("/admin/images/htwuserlookprice.jpg");
					System.out.print(rootPath11);
				     String url11=rootPath11;
				    
				    //String[] asd11 = new String[] { "python", "/root/htjavabing.py",url11,excalurl11 };
		            String[] asd11 = new String[] { "python", "D:\\eclip\\javatopy\\htjavabing.py",url11,excalurl11 };
				     javatopy(asd11 ,excalurl11);
				     
				     
				    
			     
			     
			     
			     
			     
			     
			     
		
		
		
		 return "admin/user_list";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	static void javatopy(String[] asd ,String excalurl){
		Process proc = null;
	    
	            try {
					proc = Runtime.getRuntime().exec(asd);
				} catch (IOException e4) {
					// TODO Auto-generated catch block
					e4.printStackTrace();
				}// 执行py文件
	            
	            //用输入输出流来截取结果
	            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
	            System.out.println(in);
	            
	            String line = null;
	            //String str = null;
	          String str = "";
	            try {
					while ((line = in.readLine()) != null) {
						
						 
					    System.out.println(new String (line.getBytes("utf-8"),"utf-8"));
					      str+=line;
					}
				} catch (UnsupportedEncodingException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				} catch (IOException e3) {
					// TODO Auto-generated catch block
					e3.printStackTrace();
				}
	            System.out.println("str:"+str);
	            try {
					in.close();
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
	            try {
					proc.waitFor();
				} catch (InterruptedException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
	            
	            
	     
	    
		InputStream isError = proc.getErrorStream();
		   BufferedReader br2 = new BufferedReader(new InputStreamReader(isError)); 
		   StringBuilder buf = new StringBuilder();
		   String line1 = null;
		   try {
			while((line1 = br2.readLine()) != null){
			    buf.append(line1 + "\n");
			   }
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		   System.out.println("错误输出结果为：" + buf);

		   
		    try {
				proc.waitFor();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  
	}
	
	
	
	public static void writeToXls(List resultList,String excalurl ,String tablename)throws Exception{  
			        //创建一个EXCEL  
			        Workbook wb = new HSSFWorkbook();  
			        //创建一个SHEET  
			        Sheet sheet1 = wb.createSheet(tablename);  
			                 if(resultList!=null){  
			        for (int i = 0; i < resultList.size(); i++) {  
			            //创建一行  
			            Row row = sheet1.createRow(i);  
			            List rowList=(List)resultList.get(i);  
			            for (int j = 0; j < rowList.size(); j++) {  
			                Cell cell = row.createCell(j);  
			                String cellLiString=(String)rowList.get(j);  
			                cell.setCellValue(cellLiString );  
			            }  
			        }  
			               }  
			        FileOutputStream fileOut = new FileOutputStream(excalurl);  
			        wb.write(fileOut);  
			        fileOut.close();  
			    }  
		
	}


