package com.hbsj.cart.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.hbsj.entity.showcart;

@Repository
public class cartDao {
	@Resource
    private SessionFactory sessionFactory;
	public showcart findByproIdanduserid(int productid,int userid) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		String hql = "from showcart s where s.productid=? and s.id=?";
		Query query = session.createQuery(hql);
		query.setParameter(0, productid);
		query.setParameter(1, userid);
		
		 //List<showcart> showcartList = query.list();
		showcart showcart = (showcart) query.uniqueResult();
		tx.commit();
		session.close();
		return showcart;
	}
	
	public int addshowcart(showcart showcart) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(showcart);
		tx.commit();
		session.close();
		return showcart.getOid();

	}
	public void updateshowcart(showcart objshowcart, int count) {
		System.out.println("進入了更新函數");
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		String hql="update showcart sh set sh.count=? where sh.oid=?";
		Query query = session.createQuery(hql);
		query.setParameter(0, objshowcart.getCount()+count);
		query.setParameter(1, objshowcart.getOid());
		query.executeUpdate();
		tx.commit();
		session.close();
		
	}
	public List<showcart> showdingdan(int userid) {
		Query query = this.sessionFactory.getCurrentSession().createQuery("from showcart sh where sh.state=? and sh.id=?");
		query.setParameter(0, 0);
		query.setParameter(1, userid);
		return query.list();

	}
	public List finduseridfromcart() {
		try {
			 List list=this.sessionFactory.getCurrentSession().createQuery("select s.id from showcart s").list();
			 
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public void delectproincart(int oid) {
		Session session = this.sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		String hql = "delete from showcart where oid=?";
		Query query = session.createQuery(hql);
		query.setParameter(0, oid);
		query.executeUpdate();
		tx.commit();
		session.close();
	}
	
	public List findproudtidfromcart() {
		try {
			 List list=this.sessionFactory.getCurrentSession().createQuery("select s.productid from showcart s").list();
			 
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public List findpricefromcart() {
		try {
			 List list=this.sessionFactory.getCurrentSession().createQuery("select s.price from showcart s").list();
			 
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	
}