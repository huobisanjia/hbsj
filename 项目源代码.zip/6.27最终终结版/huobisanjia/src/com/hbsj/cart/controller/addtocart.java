package com.hbsj.cart.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hbsj.cart.dao.cartDao;
import com.hbsj.entity.Computer;
import com.hbsj.entity.Computereasy;
import com.hbsj.product.dao.ProductDaoImpl;

import com.hbsj.product.service.ProductServiceImpl;
import com.hbsj.entity.Computereasy;
import com.hbsj.entity.showcart;

@Controller
@RequestMapping("/cart")
public class addtocart {
	@Resource
	private ProductServiceImpl psi;
	@Resource
	private ProductDaoImpl userDaoImpl;
	@Resource
	private ProductDaoImpl pd;
	@Resource
	private cartDao cd;
	
	
	@RequestMapping(value="/addtocart")
	public String computerCompare(@RequestParam("productId") String id, @RequestParam("count") int count,Model model, HttpSession session) {
		int productid=Integer.parseInt(id);
		
		Computereasy p = this.pd.selectEasyById(productid);
		
		
		if (session.getAttribute("userid")==null){
			JOptionPane.showMessageDialog(null, "请先登录");
			return "login";
		}
		Object obj=session.getAttribute("userid");
		int userid=Integer.parseInt(obj.toString());
		showcart show=new showcart();
		String datetime=(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")).format(Calendar.getInstance().getTime());
					show.setId(userid);
					show.setProductid(productid);
					show.setProductname(p.getCpName());
					show.setCount(count);
					show.setPrice(p.getPrice());
					show.setState(0);
					show.setRegistTime(datetime);
					show.setCpImgAdress(p.getCpImgAdress());

		showcart objshowcart=this.cd.findByproIdanduserid(productid, userid);
		if(objshowcart==null){
		 int oid=this.cd.addshowcart(show);
		}else{
		     this.cd.updateshowcart(objshowcart,count);
		     
		}
		model.addAttribute("buyinfo", "收藏成功！");
		JOptionPane.showMessageDialog(null, "收藏成功");
		model.addAttribute("productid",productid);
		return "redirect:/product/listProductDescription?evPageNum=1&cpNumber="+productid;
		
	}
	@RequestMapping(value="/showtocart")
	public String showtocart(Model model, HttpSession session) {
		Object obj=session.getAttribute("userid");
		if (obj==null){
			JOptionPane.showMessageDialog(null, "请先登录");
			return "login";
		}
		int useridd=Integer.parseInt(obj.toString());
		
		List<showcart> list = this.cd.showdingdan(useridd);
		model.addAttribute("showcartobject", list);
		return "shopcart";
		
		
	}
	
	@RequestMapping(value="/delectproincart")
	public String delectproincart(@RequestParam("incartproId") String oid, Model model, HttpSession session) {
		this.cd.delectproincart(Integer.parseInt(oid));
		
	    return "redirect:/cart/showtocart";
	
	   }
	
	@RequestMapping("/delectjiesuansuoyuan")
	public String cast(@RequestParam("ture") String stroid,
					HttpSession session, Model model){
				System.out.println(stroid);
				String listoid[]=stroid.split(",");
				int countprice=0;
				for(int i=0;i<listoid.length;i++){
					String snum	=listoid[i];
					int oid=Integer.parseInt(snum.trim());//trim()去電數字前後的空格
					
					this.cd.delectproincart(oid);
					
				}		
					return "redirect:/cart/showtocart";
					
			
	}

}
