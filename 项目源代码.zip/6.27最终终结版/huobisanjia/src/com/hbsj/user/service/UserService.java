package com.hbsj.user.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hbsj.entity.User;
import com.hbsj.user.dao.UserDao;



@Service
@Transactional
public class UserService {
	@Resource
	private UserDao userDao;
	
	public List<User> listAllUser(){
		return userDao.findAll();
	}
	
	public Integer addUser(User u){
		return userDao.addUser(u);
	}
	
	
	public void deleteById(Integer id){
		userDao.deleteByEmail(id);
	}
	
	
	public User listByUsername(String username) {
		
		//return userDao.findByUsername(username);
		return userDao.findByEmail(username);
	}
	
	public User listByEmail(String email) {
		return userDao.findByEmail(email);
	}
}
