package com.hbsj.user.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.hbsj.entity.User;



@Repository
public class UserDao {
	@Resource
	private SessionFactory sessionFactory;
	/**
	 * ��ѯȫ���û�
	 * @return
	 */
	public List<User> findAll(){
		try{
			Query query=this.sessionFactory.getCurrentSession().createQuery("from User");
			List<User> list = query.list();
			for(User u:list){
				System.out.println(u);
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public List<User> Userfindcount(){
		try{
			Query query=this.sessionFactory.getCurrentSession().createQuery("from "+User.class.getSimpleName());
			
			return query.list();
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	public List<User> userfindByPage(int pageNum, int pageSize){
		try{
			Query query=this.sessionFactory.getCurrentSession().createQuery("from "+User.class.getSimpleName());
			query.setFirstResult((pageNum-1)*pageSize);
			query.setMaxResults(pageSize);
			return query.list();
		
			
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	
	/**
	 * ����û�
	 * @return
	 */
	public Integer addUser(User u){
		try {
			this.sessionFactory.getCurrentSession().save(u);
			return u.getId();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * ����email����ѯ�û�
	 * @return
	 */
	
	public void deleteByEmail(Integer id) {
		// TODO Auto-generated method stub
		try {
			String sql = "delete User where email=?";
			Transaction t = this.sessionFactory.openSession().beginTransaction();
			Query query=this.sessionFactory.openSession().createQuery(sql);
			query.setParameter(0, id);
			t.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * �����û�������ѯ�û�
	 * @return
	 */
	public User findByUsername(String username) {
		try {
			String sql = "from User where username=?";
			Query query=this.sessionFactory.getCurrentSession().createQuery(sql);
			query.setParameter(0, username);
			User u = (User) query.uniqueResult();
			return u;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public User findByEmail(String email) {
		try {
			String sql = "from User where email=?";
			Query query=this.sessionFactory.getCurrentSession().createQuery(sql);
			query.setParameter(0, email);
			User u = (User) query.uniqueResult();
			return u;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public List finduseridfromaction() {
		try {
			 List list=this.sessionFactory.getCurrentSession().createQuery("select u.userid from useraction u").list();
			 
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public List findproidfromuserid(int uid) {
		
		try {
			Query query=this.sessionFactory.getCurrentSession().createQuery("select u.productid from useraction u where u.userid=?");
			query.setParameter(0, uid);
			List  list = query.list();
            return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public void updateById(User u) {
		Transaction tran =this.sessionFactory.getCurrentSession().beginTransaction();
		String hql = "update User u set u.username=?,u.xingming=?,u.xingbie=?,u.img_address=?,u.u_address=? where u.id=?";
		this.sessionFactory.getCurrentSession().createQuery(hql).setParameter(0, u.getUsername()).setParameter(1, u.getXingming()).setParameter(2, u.getXingbie()).setParameter(3, u.getImg_address()).setParameter(4, u.getU_address()).setParameter(5, u.getId()).executeUpdate();
		
		tran.commit();//提交事务;	

	}
	
	public List findproudtidfromaction() {
		try {
			 List list=this.sessionFactory.getCurrentSession().createQuery("select u.productid from useraction u").list();
			 
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	public List findpricefromauserction() {
		try {
			 List list=this.sessionFactory.getCurrentSession().createQuery("select u.price from useraction u").list();
			 
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}

