package com.hbsj.user.controller;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import org.apache.commons.io.FileUtils;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.multipart.commons.CommonsMultipartFile;


import com.hbsj.entity.Computereasy;
import com.hbsj.entity.Computermid;
import com.hbsj.entity.Page;
import com.hbsj.entity.User;
import com.hbsj.entity.useraction;
import com.hbsj.product.service.ProductServiceImpl;
import com.hbsj.user.dao.UserDao;
import com.hbsj.user.service.UserService;
import com.hbsj.useraction.useractionservice.UserActionService;



@Controller
@RequestMapping("/userController")
public class UserController {
	@Resource
	private UserService userService;
	@Resource
	private UserDao userdao;
	@Resource
	private ProductServiceImpl psi;
	@Resource
	private UserActionService uas;
	
	
	
	
	
	
	@RequestMapping("/deleteUser")
	public void deleteUser(Integer id){
		userService.deleteById(id);
	}
	




@RequestMapping("/indextj")
	public String computerDisplay(Model model) {
		List proidlist=userdao.findproudtidfromaction();
		HashSet h=new HashSet(proidlist);
		proidlist.clear();
		proidlist.addAll(h);
		System.out.println(proidlist);
		Collections.reverse(proidlist);//反转list
		List<Computereasy> list = new ArrayList<Computereasy>() ;
		if (proidlist.size()<9){
		for (int i = 0; i < proidlist.size(); i++) {
            int procpnumber=(int) proidlist.get(i);
            //System.out.println(useridlist.get(i));
            Computereasy computer=psi.selectCmpbycpNumber(procpnumber);
            if(computer.getCpName().length()>20) {
            	System.out.println(computer.getCpName().length());
            	computer.setCpName(computer.getCpName().substring(0, 21));
            	System.out.println(computer.getCpName());
            }
            list.add(computer);
		}
		}else{
			for (int i = 0; i < 8; i++) {
	            int procpnumber=(int) proidlist.get(i);
	            //System.out.println(useridlist.get(i));
	            Computereasy computer=psi.selectCmpbycpNumber(procpnumber);
	            if(computer.getCpName().length()>20) {
	            	System.out.println(computer.getCpName().length());
	            	computer.setCpName(computer.getCpName().substring(0, 21));
	            	System.out.println(computer.getCpName());
	            }
	            list.add(computer);	
		}
		}
		model.addAttribute("prolist", list);
		return "index";
	}
	@RequestMapping(value="/user")
	public String computeradminuser(@RequestParam("pageNum") String pageNum,HttpServletRequest request,Model model, HttpSession session) {
		//String pageNum = request.getParameter("pageNum");
		Page<Computermid> page = new Page<Computermid>();
		int num = 1;
		if (pageNum == null || pageNum.equals("")) {
			num = 1;
			page.setCurrentPageNum(num);
			
		} else {
			num = Integer.parseInt(pageNum);
			page.setCurrentPageNum(num);
		}
		int pageSize=20;
		List<User> countmid=userdao.Userfindcount();
		//List<Computermid> listmid=psii.ComputermidfindByPage(num, pageSize);
		List useridlist=userdao.userfindByPage(num, pageSize);
		page.setList(useridlist);
		page.setPageSize(pageSize);
		page.setTotalCount(countmid.size());
		model.addAttribute("page", page);
		
		System.out.println("num::"+num);
	
		
		return "admin/showulist";
	}
	
	@RequestMapping("/inuserforutopro")
	public String inuserforutopro(Model model,HttpSession session,HttpServletRequest request) {
		List  resultlist = new ArrayList();
		List useridlist=userdao.finduseridfromaction();
		HashSet h=new HashSet(useridlist);
		useridlist.clear();
		useridlist.addAll(h);
		System.out.println(useridlist);
		int usernum=useridlist.size();
		Object obj=session.getAttribute("userid");
		if (obj==null){
			JOptionPane.showMessageDialog(null, "请先登录");
			return "login";
		}
		int dangqianuserid=Integer.parseInt(obj.toString());
		
		//int dangqianuserid=7;
		for (int i = 0; i < useridlist.size(); i++) {
            int s=(int) useridlist.get(i);
            //System.out.println(useridlist.get(i));
            
            List forusertoprolist=userdao.findproidfromuserid(s);
            System.out.println("forusertoprolist"+forusertoprolist);
            HashSet h2=new HashSet(forusertoprolist);
            forusertoprolist.clear();
            forusertoprolist.addAll(h2);
    		System.out.println(forusertoprolist);
    		forusertoprolist.add(0,s);    
            resultlist.add(forusertoprolist);
            
  }
		System.out.println(resultlist);
		List list3=xietongguolu(usernum,resultlist,dangqianuserid);
		List<Computereasy> listcompeter = new ArrayList<Computereasy>() ;
		for (int i = 0; i < list3.size(); i++) {
            int procpnumber=Integer.parseInt((String) list3.get(i));
            //System.out.println(useridlist.get(i));
            Computereasy computer=psi.selectCmpbycpNumber(procpnumber);
            listcompeter.add(computer);
		}
		Page<Computereasy> page = new Page<Computereasy>();
		//page.setList(listcompeter);
		String pageNum = request.getParameter("pageNum");
		System.out.println("pageNum"+pageNum);
		int num = 1;
		if (pageNum == null || pageNum.equals("")) {
			num = 1;
			page.setCurrentPageNum(num);
			
		} else {
			num = Integer.parseInt(pageNum);
			page.setCurrentPageNum(num);
		}
		
		List<Computereasy> subList = null ;
		int pageSize=12;
		if(num<listcompeter.size()/pageSize){        //默认舍去小数部分
		 subList = listcompeter.subList(pageSize*num-pageSize, pageSize*num);
		}
		else {
			subList = listcompeter.subList(pageSize*num-pageSize, listcompeter.size());
		}
		
		page.setList(subList);
		page.setPageSize(pageSize);
		page.setTotalCount(listcompeter.size());
		
		model.addAttribute("page", page);
	
	
		model.addAttribute("page", page);
		//model.addAttribute("size", listcompeter.size());
		return "tuijian";
	}
	
	
	@RequestMapping("/personalcenter")
	public String personalCenter(Model model,HttpSession session,HttpServletRequest request) {
		List  resultlist = new ArrayList();
		List useridlist=userdao.finduseridfromaction();
		HashSet h=new HashSet(useridlist);
		useridlist.clear();
		useridlist.addAll(h);
		System.out.println(useridlist);
		int usernum=useridlist.size();
		Object obj=session.getAttribute("userid");
		if (obj==null){
			JOptionPane.showMessageDialog(null, "请先登录");
			return "login";
		}
		int dangqianuserid=Integer.parseInt(obj.toString());
		
		//int dangqianuserid=7;
		for (int i = 0; i < useridlist.size(); i++) {
            int s=(int) useridlist.get(i);
            //System.out.println(useridlist.get(i));
            
            List forusertoprolist=userdao.findproidfromuserid(s);
            System.out.println("forusertoprolist"+forusertoprolist);
            HashSet h2=new HashSet(forusertoprolist);
            forusertoprolist.clear();
            forusertoprolist.addAll(h2);
    		System.out.println(forusertoprolist);
    		forusertoprolist.add(0,s);    
            resultlist.add(forusertoprolist);
            
  }
		System.out.println(resultlist);
		List list3=xietongguolu(usernum,resultlist,dangqianuserid);
		List<Computereasy> listcompeter = new ArrayList<Computereasy>() ;
		for (int i = 0; i < list3.size(); i++) {
            int procpnumber=Integer.parseInt((String) list3.get(i));
            //System.out.println(useridlist.get(i));
            Computereasy computer=psi.selectCmpbycpNumber(procpnumber);
            listcompeter.add(computer);
		}
		Page<Computereasy> page = new Page<Computereasy>();
		//page.setList(listcompeter);
		String pageNum = request.getParameter("pageNum");
		System.out.println("pageNum"+pageNum);
		int num = 1;
		if (pageNum == null || pageNum.equals("")) {
			num = 1;
			page.setCurrentPageNum(num);
			
		} else {
			num = Integer.parseInt(pageNum);
			page.setCurrentPageNum(num);
		}
		
		List<Computereasy> subList = null ;
		int pageSize=4;
		if(num<listcompeter.size()/pageSize){        //默认舍去小数部分
		 subList = listcompeter.subList(pageSize*num-pageSize, pageSize*num);
		}
		else {
			subList = listcompeter.subList(pageSize*num-pageSize, listcompeter.size());
		}
		
		page.setList(subList);
		page.setPageSize(pageSize);
		page.setTotalCount(listcompeter.size());
		
		model.addAttribute("page", page);
	
	
		model.addAttribute("page", page);
		//model.addAttribute("size", listcompeter.size());
		return "userindex";
	}
	

	//修改个人信息
	@RequestMapping(value = "/update")
	public String queryFileData(
	             @RequestParam("uploadfile") CommonsMultipartFile file,
	             HttpServletRequest request,HttpSession session,@RequestParam("username") String username,@RequestParam("xingming") String xingming,@RequestParam("xingbie") String xingbie,@RequestParam("prov") String prov,@RequestParam("city") String city,@RequestParam("dist") String dist) {
			User u =(User) session.getAttribute("u");
			if(username!=null) {
				u.setUsername(username);
			}
			if(xingbie!=null) {
				u.setXingbie(xingbie);
			}if(xingming!=null) {
				u.setXingming(xingming);
			}
			u.setU_address(prov+"-"+city+"-"+dist);		
		
	        // MultipartFile是对当前上传的文件的封装，当要同时上传多个文件时，可以给定多个MultipartFile参数(数组)
	         if (!file.isEmpty()) {
	             String type = file.getOriginalFilename().substring(
	                     file.getOriginalFilename().indexOf("."));// 取文件格式后缀名
	            String filename = System.currentTimeMillis() + type;// 取当前时间戳作为文件名
	             String path = request.getSession().getServletContext()
	                     .getRealPath("/upload/" + filename);// 存放位置
	             File destFile = new File(path);
	                      
	            		 try {
	                 // FileUtils.copyInputStreamToFile()这个方法里对IO进行了自动操作，不需要额外的再去关闭IO流
	                 FileUtils
	                        .copyInputStreamToFile(file.getInputStream(), destFile);// 复制临时文件到指定目录下
	             } catch (IOException e) {
	                 e.printStackTrace();
	             }
	            u.setImg_address("/huobisanjia/upload/" + filename);
	            this.userdao.updateById(u);//用户信息更新
	            return "information2";
	        } else {
	        	this.userdao.updateById(u);//用户信息更新
	            return "information2";
	        }
	        
	}
	
	//用户轨迹显示
	@RequestMapping(value="/footdisplay")
	public String computersearch1(HttpServletRequest request,Model model,HttpSession session) {
		User u=(User) session.getAttribute("u");
		List<useraction> l1 = null;
		List<useraction> l3= null;
		List<useraction> l7= null;
		System.out.println("*******************************************");
		try {
			l1 = this.uas.SelectBydayAction(u.getId(), 1);
			l3 = this.uas.SelectBydayAction(u.getId(), 3);
			l7 = this.uas.SelectBydayAction(u.getId(), 7);
			session.setAttribute("yitiannei", l1);
			session.setAttribute("santiannei", l3);
			session.setAttribute("yizhounei", l7);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		
		return "foot";
		
	}
	
	
	
	
	
	
	
	
	
	
	
	public  List xietongguolu(int usernum,List resultlist,int dangqianuserid) {
	
		TreeMap<String, Double> tuijianmap = new TreeMap<String, Double>();
	    int N=usernum;
		int[][] sparseMatrix = new int[N][N];//建立用户稀疏矩阵，用于用户相似度计算【相似度矩阵】
		Map<String, Integer> userItemLength = new HashMap<>();//存储每一个用户对应的不同物品总数  eg: A 3
		Map<String, Set<String>> itemUserCollection = new HashMap<>();//建立物品到用户的倒排表 eg: a A B
		Set<String> items = new HashSet<>();//辅助存储物品集合
		Map<String, Integer> userID = new HashMap<>();//辅助存储每一个用户的用户ID映射
		Map<Integer, String> idUser = new HashMap<>();//辅助存储每一个ID对应的用户映射
		//System.out.println("Input user--items maping infermation:<eg:A a b d>");
		//scanner.nextLine();
		 String[] books = new String[resultlist.size()];
		    for(int k=0;k<resultlist.size();k++){
		    	Object[] objs = ((List) resultlist.get(k)).toArray();
		    	
		    	for(int j=0;j<objs.length;j++){
		            //System.out.println("一维数组:for:"+objs[i]);
		    		
		             books[k]+=objs[j]+" ";
		        }
		    	
		    }
		for(int i = 0; i <books.length ; i++){//依次处理N个用户 输入数据  以空格间隔
			String[] user_item = books[i].split("\\s+");
			int length = user_item.length;
			userItemLength.put(user_item[0], length-1);//eg: A 3
			userID.put(user_item[0], i);//用户ID与稀疏矩阵建立对应关系
			idUser.put(i, user_item[0]);
			//建立物品--用户倒排表
			for(int j = 1; j < length; j ++){
				if(items.contains(user_item[j])){//如果已经包含对应的物品--用户映射，直接添加对应的用户
					itemUserCollection.get(user_item[j]).add(user_item[0]);
				}else{//否则创建对应物品--用户集合映射
					items.add(user_item[j]);
					itemUserCollection.put(user_item[j], new HashSet<String>());//创建物品--用户倒排关系
					itemUserCollection.get(user_item[j]).add(user_item[0]);
				}
			}
		}
		System.out.println(itemUserCollection.toString());
		//计算相似度矩阵【稀疏】
		Set<Entry<String, Set<String>>> entrySet = itemUserCollection.entrySet();
		Iterator<Entry<String, Set<String>>> iterator = entrySet.iterator();
		while(iterator.hasNext()){
			Set<String> commonUsers = iterator.next().getValue();
			for (String user_u : commonUsers) {
				for (String user_v : commonUsers) {
					if(user_u.equals(user_v)){
						continue;
					}
					sparseMatrix[userID.get(user_u)][userID.get(user_v)] += 1;//计算用户u与用户v都有正反馈的物品总数
				}
			}
		}
		//System.out.println(userItemLength.toString());
		//System.out.println("Input the user for recommendation:<eg:A>");
		//int s=dangqianuserid;
		String s="null"+dangqianuserid;
		String recommendUser = String.valueOf(s);
		System.out.println(userID.get(recommendUser));
		//计算用户之间的相似度【余弦相似性】
		int recommendUserId = userID.get(recommendUser);
		for (int j = 0;j < sparseMatrix.length; j++) {
				if(j != recommendUserId){
					System.out.println(idUser.get(recommendUserId)+"--"+idUser.get(j)+"相似度:"+sparseMatrix[recommendUserId][j]/Math.sqrt(userItemLength.get(idUser.get(recommendUserId))*userItemLength.get(idUser.get(j))));
				}
		}
		
		//计算指定用户recommendUser的物品推荐度
		for(String item: items){//遍历每一件物品
			Set<String> users = itemUserCollection.get(item);//得到购买当前物品的所有用户集合
			if(!users.contains(recommendUser)){//如果被推荐用户没有购买当前物品，则进行推荐度计算
				double itemRecommendDegree = 0.0;
				for(String user: users){
					itemRecommendDegree += sparseMatrix[userID.get(recommendUser)][userID.get(user)]/Math.sqrt(userItemLength.get(recommendUser)*userItemLength.get(user));//推荐度计算
				}
				System.out.println("The item "+item+" for "+recommendUser +"'s recommended degree:"+itemRecommendDegree);
				tuijianmap.put(item, itemRecommendDegree);
			}
		}
		 List list2 =paixumap(tuijianmap);
		//displayAll(tuijianmap2.keySet());
		 for(int i = 0 ; i < list2.size() ; i++) {
			  System.out.println(list2.get(i));
			}
		 return list2;
	}


	private List paixumap(TreeMap<String, Double> map) {
		 List resultlist = new ArrayList();
			//这里将map.entrySet()转换成list
		        List<Map.Entry<String,Double>> list = new ArrayList<Map.Entry<String,Double>>(map.entrySet());
		        //然后通过比较器来实现排序
		        Collections.sort(list,new Comparator<Map.Entry<String,Double>>() {
		            //升序排序
		            public int compare(Entry<String, Double> o1,
		                    Entry<String, Double> o2) {
		                return o2.getValue().compareTo(o1.getValue());
		            }
		            
		        });
		        
		        for(Map.Entry<String,Double> mapping:list){ 
		               System.out.println(mapping.getKey()+":"+mapping.getValue()); 
		               //resultmap.put(mapping.getKey(),mapping.getValue());
		               resultlist.add(mapping.getKey());
		            } 
		        //return resultmap;
		        return resultlist;
		  
	}
     
  

}
