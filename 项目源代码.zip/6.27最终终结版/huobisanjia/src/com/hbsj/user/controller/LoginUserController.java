package com.hbsj.user.controller;

import javax.annotation.Resource;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hbsj.entity.User;
import com.hbsj.user.service.UserService;


@Controller
@RequestMapping("/loginuser")
public class LoginUserController {
	
	@Resource
	private UserService userService;
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(@RequestParam("username") String username,
			@RequestParam("password") String password,
			Model model, HttpSession session, HttpServletRequest request){
		User u = userService.listByUsername(username);
		
		if(u!=null&&u.getPassword().equals(password)){
			session.setAttribute("u", u);
			session.setAttribute("LoginErrorMessage",new Integer(0));
			session.setAttribute("ac", u.getAdmainac());
			session.setAttribute("userid", u.getId());
			return "index";
		}else{
			request.setAttribute("LoginErrorMessage",new Integer(1));
			return "login";
		}
	}
	@RequestMapping("/adminlogin")
	public String adminlogin(@RequestParam("username") String username,
			@RequestParam("password") String password,
			Model model, HttpSession session){
		User u = userService.listByUsername(username);
		if(u!=null&&u.getAdmainac()!=null&&u.getPassword().equals(password)){
			session.setAttribute("u", u);
			session.setAttribute("ac", u.getAdmainac());
			session.setAttribute("userid", u.getId());
			System.out.println("zzzzzzzzzzzzzzzzzzzzzzzzzz");
			return "admin/adminindex";
		}else{
			model.addAttribute("errorinfo", "您的账号密码不正确！");
			return "admin/adminlogin";
		}
	}
	@RequestMapping("/destory")
	public void destorylogin(HttpServletRequest request,HttpServletResponse response){
		HttpSession session = request.getSession();
		session.invalidate();
		try {
			response.sendRedirect("/sh/index.jsp");
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
