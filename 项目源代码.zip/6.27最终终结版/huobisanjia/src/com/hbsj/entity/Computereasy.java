package com.hbsj.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Computereasy")
public class Computereasy {
	private int cpNumber;//���
	private double price;
	private String cpName;//����
	private String cpImgAdress;//ͼƬ��ַ
	private String comments;//������
	private String hyperlinks;//��Ʒ����
	private String ciyun;
	@Id
	@GeneratedValue(generator="xho_gen")
	@GenericGenerator(name="xho_gen",strategy="increment")
	public int getCpNumber() {
		return cpNumber;
	}
	public void setCpNumber(int cpNumber) {
		this.cpNumber = cpNumber;
	}
	public String getCpName() {
		return cpName;
	}
	public void setCpName(String cpName) {
		this.cpName = cpName;
	}
	public String getCiyun() {
		return ciyun;
	}
	public void setCiyun(String ciyun) {
		this.ciyun = ciyun;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getCpImgAdress() {
		return cpImgAdress;
	}
	public void setCpImgAdress(String cpImgAdress) {
		this.cpImgAdress = cpImgAdress;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getHyperlinks() {
		return hyperlinks;
	}
	public void setHyperlinks(String hyperlinks) {
		this.hyperlinks = hyperlinks;
	}
	
}
