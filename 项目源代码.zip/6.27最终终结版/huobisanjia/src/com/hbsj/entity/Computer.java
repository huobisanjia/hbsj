package com.hbsj.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Computer")
public class Computer {
	private int cpNumber;//���
	//private String cpName;//����
	//private String cpImgAdress;//ͼƬ��ַ
	//private String comments;//������
	//private String hyperlinks;//��Ʒ����
	
	//private int price;
	//private String businesses;//�̼�
	//private String rating;//����
	//private String brand;//Ʒ��
	//private String markettime;//����ʱ��
	//private String screensize;//��Ļ�ߴ�
	//private String cpu;//cpu
	//private String producttype;//��Ʒ����
	//private String graphics;//�Կ�
	
	private String cpPinpai;//Ʒ����
	private String cpXinghao;//�ͺ�
	private String zuidibaojia;//��ͱ���
	//private String tuijianxingshu;//�Ƽ�����
	private String shangshishijian;//����ʱ��
	private String chanpinleixing;//��Ʒ����
	private String chanpindingwei;//��Ʒ��λ
	private String caozuoxitong;//����ϵͳ
	//private String chicun;//�ߴ�
	private String cpuxilie;//cpuϵ��
	private String cpuxinghao;//cpu�ͺ�
	private String cpuzhupin;//cpu��Ƶ
	private String zuigaoruipin;//����Ƶ
	private String zongxianguige;//���߹��
	private String sanjihuancun;//��������
	private String hexinxianchengshu;//����/�߳���
	private String zhichenggongyi;//�Ƴ̹���
	private String gonghao;//����
	private String cpuleixing;//cpu����
	private String hexinjiagou;//���ļܹ�
	private String neicunrongliang;//�ڴ�����
	private String neicunleixing;//�ڴ�����
	private String chacaoshuliang;//�������
	private String zuidaneicunrongliang;//����ڴ�����
	private String yingpanrongliang;//Ӳ������
	private String yingpanmiaoshu;//Ӳ������
	private String guangquleixing;//��������
	private String pingmuchicun;//��Ļ�ߴ�
	private String pingmufenbianlv;//��Ļ�ֱ���
	private String chukongping;//������
	private String xianshibili;//��ʾ����
	private String pingmujishu;//��Ļ����
	private String xiankaleixing;//�Կ�����
	private String xiankaxinpian;//�Կ�оƬ
	private String xiancunrongliang;//�Դ�����
	private String xiancunleixing;//�Դ�����
	private String xiancunweikuan;//�Դ�λ��
	private String shexiangtou;//����ͷ
	private String yinpinxitong;//��Ƶϵͳ
	private String yangshengqi;//������
	private String maikefeng;//��˷�
	private String wuxianwangka;//��������
	private String youxianwangka;//��������
	private String lanya;//����
	private String shujujiekou;//���ݽӿ�
	private String shipinjiekou;//��Ƶ�ӿ�
	private String yinpinjiekou;//��Ƶ�ӿ�
	private String qitajiekou;//�����ӿ�
	private String dukaqi;//������
	private String zhiqushebei;//ָȡ�豸
	private String jianpanmiaoshu;//��������
	private String dianchileixing;//�������
	private String xuhangshijian;//����ʱ��
	private String dianyuanshipeiqi;//��Դ������
	private String bijibenzhongliang;//�ʼǱ�����
	private String changdu;//����
	private String kuandu;//����
	private String houdu;//���
	private String waikecaizhi;//��ǲ���
	private String waikemiaoshu;//�������
	private String fudairuanjian;//��������
	private String baozhuangqingdan;//��װ�嵥
	private String kexuanpeijian;//��ѡ���
	private String baoxiuzhengce;//��������
	private String zhibaoshijian;//�ʱ�ʱ��
	private String zhibaobeizhu;//�ʱ���ע
	private String kefudianhua;//�ͷ��绰
	private String dianhuabeizhu;//�绰��ע
	private String xiangxineirong;//��ϸ����
	
	@Id
	@GeneratedValue(generator="xho_gen")
	@GenericGenerator(name="xho_gen",strategy="increment")
	public int getCpNumber() {
		return cpNumber;
	}
	public void setCpNumber(int cpNumber) {
		this.cpNumber = cpNumber;
	}

	public String getCpPinpai() {
		return cpPinpai;
	}
	public void setCpPinpai(String cpPinpai) {
		this.cpPinpai = cpPinpai;
	}
	public String getCpXinghao() {
		return cpXinghao;
	}
	public void setCpXinghao(String cpXinghao) {
		this.cpXinghao = cpXinghao;
	}
	public String getZuidibaojia() {
		return zuidibaojia;
	}
	public void setZuidibaojia(String zuidibaojia) {
		this.zuidibaojia = zuidibaojia;
	}
	public String getShangshishijian() {
		return shangshishijian;
	}
	public void setShangshishijian(String shangshishijian) {
		this.shangshishijian = shangshishijian;
	}
	public String getChanpinleixing() {
		return chanpinleixing;
	}
	public void setChanpinleixing(String chanpinleixing) {
		this.chanpinleixing = chanpinleixing;
	}
	public String getChanpindingwei() {
		return chanpindingwei;
	}
	public void setChanpindingwei(String chanpindingwei) {
		this.chanpindingwei = chanpindingwei;
	}
	public String getCaozuoxitong() {
		return caozuoxitong;
	}
	public void setCaozuoxitong(String caozuoxitong) {
		this.caozuoxitong = caozuoxitong;
	}
	public String getCpuxilie() {
		return cpuxilie;
	}
	public void setCpuxilie(String cpuxilie) {
		this.cpuxilie = cpuxilie;
	}
	public String getCpuxinghao() {
		return cpuxinghao;
	}
	public void setCpuxinghao(String cpuxinghao) {
		this.cpuxinghao = cpuxinghao;
	}
	public String getCpuzhupin() {
		return cpuzhupin;
	}
	public void setCpuzhupin(String cpuzhupin) {
		this.cpuzhupin = cpuzhupin;
	}
	public String getZuigaoruipin() {
		return zuigaoruipin;
	}
	public void setZuigaoruipin(String zuigaoruipin) {
		this.zuigaoruipin = zuigaoruipin;
	}
	public String getZongxianguige() {
		return zongxianguige;
	}
	public void setZongxianguige(String zongxianguige) {
		this.zongxianguige = zongxianguige;
	}
	public String getSanjihuancun() {
		return sanjihuancun;
	}
	public void setSanjihuancun(String sanjihuancun) {
		this.sanjihuancun = sanjihuancun;
	}
	public String getHexinxianchengshu() {
		return hexinxianchengshu;
	}
	public void setHexinxianchengshu(String hexinxianchengshu) {
		this.hexinxianchengshu = hexinxianchengshu;
	}
	public String getZhichenggongyi() {
		return zhichenggongyi;
	}
	public void setZhichenggongyi(String zhichenggongyi) {
		this.zhichenggongyi = zhichenggongyi;
	}
	public String getGonghao() {
		return gonghao;
	}
	public void setGonghao(String gonghao) {
		this.gonghao = gonghao;
	}
	public String getCpuleixing() {
		return cpuleixing;
	}
	public void setCpuleixing(String cpuleixing) {
		this.cpuleixing = cpuleixing;
	}
	public String getHexinjiagou() {
		return hexinjiagou;
	}
	public void setHexinjiagou(String hexinjiagou) {
		this.hexinjiagou = hexinjiagou;
	}
	public String getNeicunrongliang() {
		return neicunrongliang;
	}
	public void setNeicunrongliang(String neicunrongliang) {
		this.neicunrongliang = neicunrongliang;
	}
	public String getNeicunleixing() {
		return neicunleixing;
	}
	public void setNeicunleixing(String neicunleixing) {
		this.neicunleixing = neicunleixing;
	}
	public String getChacaoshuliang() {
		return chacaoshuliang;
	}
	public void setChacaoshuliang(String chacaoshuliang) {
		this.chacaoshuliang = chacaoshuliang;
	}
	public String getZuidaneicunrongliang() {
		return zuidaneicunrongliang;
	}
	public void setZuidaneicunrongliang(String zuidaneicunrongliang) {
		this.zuidaneicunrongliang = zuidaneicunrongliang;
	}
	public String getYingpanrongliang() {
		return yingpanrongliang;
	}
	public void setYingpanrongliang(String yingpanrongliang) {
		this.yingpanrongliang = yingpanrongliang;
	}
	public String getYingpanmiaoshu() {
		return yingpanmiaoshu;
	}
	public void setYingpanmiaoshu(String yingpanmiaoshu) {
		this.yingpanmiaoshu = yingpanmiaoshu;
	}
	public String getGuangquleixing() {
		return guangquleixing;
	}
	public void setGuangquleixing(String guangquleixing) {
		this.guangquleixing = guangquleixing;
	}
	public String getPingmuchicun() {
		return pingmuchicun;
	}
	public void setPingmuchicun(String pingmuchicun) {
		this.pingmuchicun = pingmuchicun;
	}
	public String getPingmufenbianlv() {
		return pingmufenbianlv;
	}
	public void setPingmufenbianlv(String pingmufenbianlv) {
		this.pingmufenbianlv = pingmufenbianlv;
	}
	public String getChukongping() {
		return chukongping;
	}
	public void setChukongping(String chukongping) {
		this.chukongping = chukongping;
	}
	public String getXianshibili() {
		return xianshibili;
	}
	public void setXianshibili(String xianshibili) {
		this.xianshibili = xianshibili;
	}
	public String getPingmujishu() {
		return pingmujishu;
	}
	public void setPingmujishu(String pingmujishu) {
		this.pingmujishu = pingmujishu;
	}
	public String getXiankaleixing() {
		return xiankaleixing;
	}
	public void setXiankaleixing(String xiankaleixing) {
		this.xiankaleixing = xiankaleixing;
	}
	public String getXiankaxinpian() {
		return xiankaxinpian;
	}
	public void setXiankaxinpian(String xiankaxinpian) {
		this.xiankaxinpian = xiankaxinpian;
	}
	public String getXiancunrongliang() {
		return xiancunrongliang;
	}
	public void setXiancunrongliang(String xiancunrongliang) {
		this.xiancunrongliang = xiancunrongliang;
	}
	public String getXiancunleixing() {
		return xiancunleixing;
	}
	public void setXiancunleixing(String xiancunleixing) {
		this.xiancunleixing = xiancunleixing;
	}
	public String getXiancunweikuan() {
		return xiancunweikuan;
	}
	public void setXiancunweikuan(String xiancunweikuan) {
		this.xiancunweikuan = xiancunweikuan;
	}
	public String getShexiangtou() {
		return shexiangtou;
	}
	public void setShexiangtou(String shexiangtou) {
		this.shexiangtou = shexiangtou;
	}
	public String getYinpinxitong() {
		return yinpinxitong;
	}
	public void setYinpinxitong(String yinpinxitong) {
		this.yinpinxitong = yinpinxitong;
	}
	public String getYangshengqi() {
		return yangshengqi;
	}
	public void setYangshengqi(String yangshengqi) {
		this.yangshengqi = yangshengqi;
	}
	public String getMaikefeng() {
		return maikefeng;
	}
	public void setMaikefeng(String maikefeng) {
		this.maikefeng = maikefeng;
	}
	public String getWuxianwangka() {
		return wuxianwangka;
	}
	public void setWuxianwangka(String wuxianwangka) {
		this.wuxianwangka = wuxianwangka;
	}
	public String getYouxianwangka() {
		return youxianwangka;
	}
	public void setYouxianwangka(String youxianwangka) {
		this.youxianwangka = youxianwangka;
	}
	public String getLanya() {
		return lanya;
	}
	public void setLanya(String lanya) {
		this.lanya = lanya;
	}
	public String getShujujiekou() {
		return shujujiekou;
	}
	public void setShujujiekou(String shujujiekou) {
		this.shujujiekou = shujujiekou;
	}
	public String getShipinjiekou() {
		return shipinjiekou;
	}
	public void setShipinjiekou(String shipinjiekou) {
		this.shipinjiekou = shipinjiekou;
	}
	public String getYinpinjiekou() {
		return yinpinjiekou;
	}
	public void setYinpinjiekou(String yinpinjiekou) {
		this.yinpinjiekou = yinpinjiekou;
	}
	public String getQitajiekou() {
		return qitajiekou;
	}
	public void setQitajiekou(String qitajiekou) {
		this.qitajiekou = qitajiekou;
	}
	public String getDukaqi() {
		return dukaqi;
	}
	public void setDukaqi(String dukaqi) {
		this.dukaqi = dukaqi;
	}
	public String getZhiqushebei() {
		return zhiqushebei;
	}
	public void setZhiqushebei(String zhiqushebei) {
		this.zhiqushebei = zhiqushebei;
	}
	public String getJianpanmiaoshu() {
		return jianpanmiaoshu;
	}
	public void setJianpanmiaoshu(String jianpanmiaoshu) {
		this.jianpanmiaoshu = jianpanmiaoshu;
	}
	public String getDianchileixing() {
		return dianchileixing;
	}
	public void setDianchileixing(String dianchileixing) {
		this.dianchileixing = dianchileixing;
	}
	public String getXuhangshijian() {
		return xuhangshijian;
	}
	public void setXuhangshijian(String xuhangshijian) {
		this.xuhangshijian = xuhangshijian;
	}
	public String getDianyuanshipeiqi() {
		return dianyuanshipeiqi;
	}
	public void setDianyuanshipeiqi(String dianyuanshipeiqi) {
		this.dianyuanshipeiqi = dianyuanshipeiqi;
	}
	public String getBijibenzhongliang() {
		return bijibenzhongliang;
	}
	public void setBijibenzhongliang(String bijibenzhongliang) {
		this.bijibenzhongliang = bijibenzhongliang;
	}
	public String getChangdu() {
		return changdu;
	}
	public void setChangdu(String changdu) {
		this.changdu = changdu;
	}
	public String getKuandu() {
		return kuandu;
	}
	public void setKuandu(String kuandu) {
		this.kuandu = kuandu;
	}
	public String getHoudu() {
		return houdu;
	}
	public void setHoudu(String houdu) {
		this.houdu = houdu;
	}
	public String getWaikecaizhi() {
		return waikecaizhi;
	}
	public void setWaikecaizhi(String waikecaizhi) {
		this.waikecaizhi = waikecaizhi;
	}
	public String getFudairuanjian() {
		return fudairuanjian;
	}
	public void setFudairuanjian(String fudairuanjian) {
		this.fudairuanjian = fudairuanjian;
	}
	public String getBaozhuangqingdan() {
		return baozhuangqingdan;
	}
	public void setBaozhuangqingdan(String baozhuangqingdan) {
		this.baozhuangqingdan = baozhuangqingdan;
	}
	public String getKexuanpeijian() {
		return kexuanpeijian;
	}
	public void setKexuanpeijian(String kexuanpeijian) {
		this.kexuanpeijian = kexuanpeijian;
	}
	public String getBaoxiuzhengce() {
		return baoxiuzhengce;
	}
	public void setBaoxiuzhengce(String baoxiuzhengce) {
		this.baoxiuzhengce = baoxiuzhengce;
	}
	public String getZhibaoshijian() {
		return zhibaoshijian;
	}
	public void setZhibaoshijian(String zhibaoshijian) {
		this.zhibaoshijian = zhibaoshijian;
	}
	public String getZhibaobeizhu() {
		return zhibaobeizhu;
	}
	public void setZhibaobeizhu(String zhibaobeizhu) {
		this.zhibaobeizhu = zhibaobeizhu;
	}
	public String getKefudianhua() {
		return kefudianhua;
	}
	public void setKefudianhua(String kefudianhua) {
		this.kefudianhua = kefudianhua;
	}
	public String getDianhuabeizhu() {
		return dianhuabeizhu;
	}
	public void setDianhuabeizhu(String dianhuabeizhu) {
		this.dianhuabeizhu = dianhuabeizhu;
	}
	public String getXiangxineirong() {
		return xiangxineirong;
	}
	public void setXiangxineirong(String xiangxineirong) {
		this.xiangxineirong = xiangxineirong;
	}
	public String getWaikemiaoshu() {
		return waikemiaoshu;
	}
	public void setWaikemiaoshu(String waikemiaoshu) {
		this.waikemiaoshu = waikemiaoshu;
	}
	
	
}
