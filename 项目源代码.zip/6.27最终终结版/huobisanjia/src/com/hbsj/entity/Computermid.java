package com.hbsj.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="Computermid")
public class Computermid {
	private int cpNumber;//���
	private String cpName;//����
	private String price;
	private String businesses;//�̼�
	private String rating;//����
	private String brand;//Ʒ��
	private String markettime;//����ʱ��
	private String screensize;//��Ļ�ߴ�
	private String cpu;//cpu
	private String producttype;//��Ʒ����
	private String graphics;//�Կ�
	@Id
	@GeneratedValue(generator="xho_gen")
	@GenericGenerator(name="xho_gen",strategy="increment")
	public int getCpNumber() {
		return cpNumber;
	}
	public void setCpNumber(int cpNumber) {
		this.cpNumber = cpNumber;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getBusinesses() {
		return businesses;
	}
	public void setBusinesses(String businesses) {
		this.businesses = businesses;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getMarkettime() {
		return markettime;
	}
	public void setMarkettime(String markettime) {
		this.markettime = markettime;
	}
	public String getScreensize() {
		return screensize;
	}
	public void setScreensize(String screensize) {
		this.screensize = screensize;
	}
	public String getCpu() {
		return cpu;
	}
	public void setCpu(String cpu) {
		this.cpu = cpu;
	}
	public String getProducttype() {
		return producttype;
	}
	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}
	public String getGraphics() {
		return graphics;
	}
	public void setGraphics(String graphics) {
		this.graphics = graphics;
	}
	public String getCpName() {
		return cpName;
	}
	public void setCpName(String cpName) {
		this.cpName = cpName;
	}
	
}
