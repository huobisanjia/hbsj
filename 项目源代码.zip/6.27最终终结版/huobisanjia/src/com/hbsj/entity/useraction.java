package com.hbsj.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="useraction")
public class useraction {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int oid;//������
	private int userid;//�û���ID
	private String productname;
	private double price;
	private String registTime;
	private int productid;//��ƷID
	private String  cpImgAdress;
	
	public String getCpImgAdress() {
		return cpImgAdress;
	}

	public void setCpImgAdress(String string) {
		this.cpImgAdress = string;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	@Id
	@GeneratedValue(generator="my_gen")
    @GenericGenerator(name = "my_gen", strategy = "increment")
	public int getOid() {
		return oid;
	}

	public void setOid(int oid) {
		this.oid = oid;
	}


	

	
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getuserid() {
		return userid;
	}

	public void setuserid(int userid) {
		this.userid = userid;
	}
	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	
	
	
	public String getregistTime() {
		return registTime;
	}

	public void setregistTime(String registTime) {
		this.registTime = registTime;
	}

	

	public useraction() {
		// TODO Auto-generated constructor stub
	}

}



