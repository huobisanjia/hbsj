package com.hbsj.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
	@Entity
	@Table(name="showcart")
	public class showcart {
		private int oid;//自增键
		private int id;//用户名ID
		private String productname;
		private int count;
		private double price;
		private String registTime;
		private int productid;//产品ID
		private int state;
		private String cpImgAdress;
		public String getCpImgAdress() {
			return cpImgAdress;
		}
		public void setCpImgAdress(String cpImgAdress) {
			this.cpImgAdress = cpImgAdress;
		}
		@Id
		@GeneratedValue(generator="my_gen")
	    @GenericGenerator(name = "my_gen", strategy = "increment")
		public int getOid() {
			return oid;
		}
		public void setOid(int oid) {
			this.oid = oid;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getProductname() {
			return productname;
		}
		public void setProductname(String productname) {
			this.productname = productname;
		}
		public int getCount() {
			return count;
		}
		public void setCount(int count) {
			this.count = count;
		}
		public String getRegistTime() {
			return registTime;
		}
		public void setRegistTime(String registTime) {
			this.registTime = registTime;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		
		public int getProductid() {
			return productid;
		}
		public void setProductid(int productid) {
			this.productid = productid;
		}
		public int getState() {
			return state;
		}
		public void setState(int state) {
			this.state = state;
		}
		
}
